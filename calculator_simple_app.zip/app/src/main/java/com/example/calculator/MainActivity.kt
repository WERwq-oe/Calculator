package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import kotlin.math.round

class MainActivity : ComponentActivity() {
    private lateinit var display: TextView
    private var current = ""
    private var operand: Double? = null
    private var pendingOp: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display)

        val btnIds = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btnDot
        )
        btnIds.forEach { id ->
            findViewById<Button>(id).setOnClickListener { v ->
                val txt = (v as Button).text.toString()
                appendNumber(txt)
            }
        }

        val opIds = listOf(R.id.btnAdd, R.id.btnSub, R.id.btnMul, R.id.btnDiv)
        opIds.forEach { id ->
            findViewById<Button>(id).setOnClickListener { v ->
                val op = (v as Button).text.toString()
                applyOp(op)
            }
        }

        findViewById<Button>(R.id.btnEq).setOnClickListener { performEquals() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearAll() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { backspace() }
    }

    private fun appendNumber(s: String) {
        if (s == "." && current.contains('.')) return
        current += s
        display.text = current
    }

    private fun applyOp(op: String) {
        if (current.isEmpty() && operand == null) return
        val value = current.toDoubleOrNull()
        if (value != null) {
            if (operand == null) operand = value
            else operand = calculate(operand!!, value, pendingOp)
        }
        pendingOp = op
        current = ""
        display.text = (operand?.let { trimNumber(it) } ?: "")
    }

    private fun performEquals() {
        val value = current.toDoubleOrNull()
        if (value == null || pendingOp == null || operand == null) return
        operand = calculate(operand!!, value, pendingOp)
        display.text = trimNumber(operand!!)
        current = ""
        pendingOp = null
    }

    private fun calculate(a: Double, b: Double, op: String?): Double {
        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "×", "*" -> a * b
            "÷", "/" -> a / b
            else -> b
        }
    }

    private fun clearAll() {
        current = ""
        operand = null
        pendingOp = null
        display.text = "0"
    }

    private fun backspace() {
        if (current.isNotEmpty()) {
            current = current.dropLast(1)
            display.text = if (current.isEmpty()) "0" else current
        }
    }

    private fun trimNumber(d: Double): String {
        // Remove trailing .0 when integer
        return if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
    }
}
